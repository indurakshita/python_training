a = 1
b = 1


# # Equal to operator
# print(f"{a == b = }")

# # Not Equal to operator
# print(f"{a != b = }")

# # Greater than operator
# print(f"{a > b = }")

# # Less than operator
# print(f"{a < b = }")


# # Greater than or Equal to operator
# print(f"{a >= b = }")

# # Less than or Equal to operator
# print(f"{a <= b = }")



# Chained operators
a = 2
b = 3
c = 4

# print(f"{a <= b < c >= a = }")

# AND OR
# print(f"{(a < b) or (c < b < a) and (c >= a) = }")