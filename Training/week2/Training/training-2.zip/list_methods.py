st1 = {"Apple", "Orange", 2, "Orange"}
st2 = {"Apple", "Mango", 1, "Orange", "Orange"}
st3 = {1,2,3}
# Adds an element
# st1.add(2)


# Clears the set
# st.clear()

diff = st1.update(st3)

print(st1)