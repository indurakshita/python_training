import tldextract
from urllib.parse import urlparse

request = type("request", (), {"url": "http://develop.onecare.com/api/v4/42/q?v=8#index"})

subdomain = tldextract.extract(request.url)

# subdomain = urlparse(request.url)

print(subdomain)