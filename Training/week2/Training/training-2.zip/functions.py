# Functions

# Functions are used to run a set of tasks or to group tasks
# able to call multiple times whenever needed
# able to pass arguments and keyword arguments as th input

# Two types of arguments
# Positional and Keyword Arguments
# if we set a default value to a positional argument it becomes keyword argument
# Dont forget the order !!!!!!
# (Keyword argument comes after postional argument)
# *args and **kwargs
# *args returns a tuple
# **kwargs returns dictionary


# Positional Arguments (args)
def get_args(name, age):
    return f"my name is {name} and I am {age} years old"

# Keyword Arguments (kwargs)
def get_args(name=None, age=None):
    return f"my name is {name} and I am {age} years old"


# When we have uncertainity about the inputs we get we use *args and **kwargs
# Arguments (*args)
def get_args(*args):
    return args

# Arguments (**kwargs)
def get_kwargs(**kwargs):
    return kwargs

# example combination
def get_combination(name, age=25, *args, **kwargs):
    return name, args, age, kwargs


# args = get_args("albin", "anthony", 25, True, "hello", 3.2)
# kwargs = get_kwargs(fname="albin", lname="anthony", age=25, dveveloper=True, messsage="hello", point=3.2)
comb = get_combination("albin", "Anthony", distance=36)
# print(comb)


# addition (normal function)
def addition(x, y):
    ...
    ...
    ...
    ...
    ...
    ...
    return x+y

# add = addition(2, 5)


# Anonymous function or lambda function addition
anon = lambda x, y: x+y

# print(anon(2, 5))



# recursion
def call_self(out):
    if not out == 5:
        out += 1
        return call_self(out)
    return out

final = call_self(1)
# print(final)
