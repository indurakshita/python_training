# Recommended naming conventions
snake_case_variable = "I am a snake case variable" # Snake case (naming variables, function definitions) Not for class definitions

snake_case_variable567 = "I am a snake case variable" # Snake case (naming variables)

PascalCaseVariable = "I am a Pascal case Variable" # Pascal Case (defining classes or class definitions)

PascalCaseVariable234 = "I am a Pascal case Variable" # Pascal Case (defining classes or class definitions)
# not recomended for defining class with numbers at the end but can be used in situations like avoiding duplications

UPPERCASE = "I am a upper case variable" # upper case (For defining constants)

_test = "test"

# Not Recommended naming conventions
camelCase = "Not recomended"

# Not Allowed or naming conventions
# @somevariable = "Throws error"
# 2some_variable  = "Throws error"
#  some_variable = "Throws error"
# some, variable = "Throws error"